export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const {
    discord,
    age,
    fivemName,
    timezone,
    role,
    experience,
    whyJoin,
    strengths,
    availability,
    extra
  } = req.body || {};

  if (!discord || !age || !fivemName || !timezone || !role || !experience || !whyJoin || !strengths || !availability) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  if (!process.env.DISCORD_WEBHOOK_URL) {
    return res.status(500).json({ error: "Missing Discord webhook environment variable" });
  }

  const embed = {
    title: "New Operation Blackout Application",
    color: 8255831,
    fields: [
      { name: "Discord", value: String(discord), inline: true },
      { name: "Age", value: String(age), inline: true },
      { name: "FiveM / Steam Name", value: String(fivemName), inline: true },
      { name: "Time Zone", value: String(timezone), inline: true },
      { name: "Preferred Role", value: String(role), inline: true },
      { name: "Experience", value: String(experience), inline: true },
      { name: "Why Join?", value: String(whyJoin).slice(0, 1024) },
      { name: "Strengths", value: String(strengths).slice(0, 1024) },
      { name: "Availability", value: String(availability).slice(0, 1024) },
      { name: "Extra", value: extra ? String(extra).slice(0, 1024) : "N/A" }
    ],
    timestamp: new Date().toISOString(),
    footer: { text: "Operation Blackout Applications" }
  };

  try {
    const discordResponse = await fetch(process.env.DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: "Operation Blackout Applications",
        embeds: [embed]
      })
    });

    if (!discordResponse.ok) {
      const discordError = await discordResponse.text();
      return res.status(500).json({ error: "Discord webhook failed", details: discordError });
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    return res.status(500).json({ error: "Server error", details: error.message });
  }
}
